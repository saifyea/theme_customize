<?php
include 'header.php';
?>


<?php
include 'content.php';
?>

<?php
include 'sidebar.php';
?>

<?php
include 'footer.php';
?>
